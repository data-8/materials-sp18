test = {
  'name': 'Question 6_3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> all_different.lower() in {'yes', 'no'}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
