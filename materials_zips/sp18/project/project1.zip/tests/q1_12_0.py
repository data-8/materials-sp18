test = {
  'name': 'Question 1_12_0',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Check for correct output of helper function
          >>> pop_for_year(1972) == 3345978384
          True
          >>> pop_for_year(1989) == 4567880153
          True
          >>> pop_for_year(2002) == 5501335945
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
